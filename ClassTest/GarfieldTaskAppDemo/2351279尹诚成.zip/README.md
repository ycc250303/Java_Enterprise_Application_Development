# 加菲猫任务管理系统

## 项目作者

* 学号：2351279
* 姓名：尹诚成

## 项目结构

* `GarfieldTaskApp`: 项目主程序
* `GarfieldTaskCommand`: 项目命令控制
* `commands\`: 命令示例
* `repository\`: 任务管理仓库
* `service\`: 番茄钟、json生成服务
* `task\`: 任务信息

## 项目运行

* 开启IEDA，在`GarfieldTaskApp.java`文件中用`ctrl+F5`启动，或者点击图形化启动按钮

## 未完成功能

* `add` 添加deadline类型的任务
* deadline 任务的超时判断
* 其余功能未能详细测试正确性